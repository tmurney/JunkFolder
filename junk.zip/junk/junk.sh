#! /bin/bash

#Name: Thomas Murney
#Student Number: S1513911 
#Script: Junk Folder Utility For Linux Mint

if [ ! -d ~/.junkdir ] 
then
	echo "Junk folder not found, creating directory..." 
	mkdir ~/.junkdir/
else 
	echo "Junk folder found, running script..."
fi

	

view_files(){
for file in ~/.junkdir/
do 
	stat -c "%n %B %F" $file
done
}

recover_files(){
cd ~/.junkdir/
echo "Enter the name of the file you're looking for"
read filename

for file in ~/.junkdir/
do
if [ -f $filename ] 
then echo "Recovering file..."
mv $filename ~/Desktop/
else echo "Error: File Not Found"
fi
done
} 

delete_files(){
cd ~/.junkdir/
echo "Enter the name of the file you're looking for"
read filename 

for file in *
do
if [ -f $filename ] 
then echo "Removing file..."
rm $filename
else echo "Error: File Not Found"
fi
done
}


view_size(){
#Function for displaying total size
#Display size of the folder
#If greater than 1KB
#Then display warning
}


#GETOPTS Statement for menu

#GETOPTS Statment




