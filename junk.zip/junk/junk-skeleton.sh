#! /bin/bash
USAGE="usage: $0 <fill in correct usage>" 

if [ ! -d ~/.junkdir ] 
then
	echo "Junk Folder Not Found, Creating Directory" 
	mkdir ~/.junkdir/
else 
	echo "Junk Folder Found, running script..."
fi



view_files(){
cd ~/.junkdir/
for file in *
do 
stat -c "%n %B %F" $file
done

cd ..
}



recover_files(){
cd ~/.junkdir/
echo "Enter the name of the file you're looking for"
read filename

for file in ~/.junkdir/
do
if [ -f $filename ] 
then echo "Recovering file..."
mv $filename ~/Desktop/
else echo "Error: File Not Found"
fi
done

} 

delete_files(){
cd ~/.junkdir/
echo "Enter the name of the file you're looking for"
read filename 

for file in *
do
if [ -f $filename ] 
then echo "Removing file..."
rm $filename
else echo "Error: File Not Found"
fi
done
}



while getopts :lr:dtwk args #options
do
  case $args in
     l) echo "l option";;
     r) echo "r option; data: $OPTARG";;
     d) echo "d option";; 
     t) echo "t option";; 
     w) echo "w option";; 
     k) echo "k option";;     
     :) echo "data missing, option -$OPTARG";;
    \?) echo "$USAGE";;
  esac
done

((pos = OPTIND - 1))
shift $pos

PS3='option> '

if (( $# == 0 ))
then if (( $OPTIND == 1 )) 
 then select menu_list in list recover delete total watch kill exit
      do case $menu_list in
         "list") view_files;;
         "recover") recover_files;;
         "delete") delete_files;;
         "total") echo "t";;
         "watch") echo "w";;
         "kill") echo "k";;
         "exit") exit 0;;
         *) echo "unknown option";;
         esac
      done
 fi
else echo "extra args??: $@"
fi


