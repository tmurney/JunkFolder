#! /bin/bash
USAGE="usage: $0 <fill in correct usage>" 

scriptDirectory="$PWD"


if [ ! -d ~/.junkdir ] 
then
	echo "Junk Folder Not Found, Creating Directory" 
	mkdir ~/.junkdir/
else 
	echo "Junk Folder Found, running script..."
fi



view_files(){

cd ~/.junkdir/

for file in *
do 
	stat -c "%n %B %F" $file
done

cd $scriptDirectory
}



recover_files(){
cd ~/.junkdir/
echo "Enter the name of the file you're looking for"
read filename

if [ -f $filename ] 
	then echo "Recovering file..."
	mv $filename $scriptDirectory
	else echo "Error: File Not Found"
fi

cd $scriptDirectory
} 

recover_files_shortcut(){
cd ~/.junkdir/

if [ -f $filename ]
	then echo "Recovering file..."
	mv $filename $scriptDirectory
	else echo "Error: File Not Found"
fi

cd $scriptDirectory
}



delete_files(){
cd ~/.junkdir/

ls
echo "Enter the name of the file you wish to delete..."
read filename 

if [ -f $filename ] 
	then echo "Removing file..."
	rm $filename
	else echo "Error: File Not Found"
fi

}

display_total(){
total= du -h

if [ $total > 1 ]
then echo "WARNING: THE JUNK FOLDER HAS EXCEEDED THE RECOMMENDED AMOUNT"
fi

}

while getopts :lr:dt args #options
do
  case $args in
     l) view_files;;
     r) filename=$OPTARG; recover_files_shortcut;;
     d) delete_files;; 
     t) display_total;;    
     :) echo "data missing";;
    \?) echo "$USAGE";;
  esac
done

((pos = OPTIND - 1))
shift $pos

PS3='option> '

if (( $# == 0 ))
then if (( $OPTIND == 1 )) 
 then select menu_list in list recover delete total exit
      do case $menu_list in
         "list") view_files;;
         "recover") recover_files;;
         "delete") delete_files;;
         "total") display_total;;
         "exit") exit 0;;
         *) echo "unknown option";;
         esac
      done
 fi
else echo "extra args??: $@"
fi


